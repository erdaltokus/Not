package com.notewidget.app

import android.app.Application
import com.notewidget.app.data.AppDatabase
import com.notewidget.app.data.NoteRepository
import com.notewidget.app.data.SettingsRepository

class NoteApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { NoteRepository(database.noteDao()) }
    val settingsRepository by lazy { SettingsRepository(this) }
}
