package com.notewidget.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.notewidget.app.NoteApp
import com.notewidget.app.data.Note
import com.notewidget.app.ui.theme.NoteWidgetAppTheme
import com.notewidget.app.widget.NotesWidget
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NoteWidgetAppTheme {
                val app = application as NoteApp
                val viewModel: NotesViewModel = viewModel(
                    factory = NotesViewModelFactory(app.repository, app.settingsRepository)
                )
                NotesScreen(
                    viewModel = viewModel,
                    onNoteClick = { note ->
                        startActivity(Intent(this, NoteDetailActivity::class.java).apply {
                            putExtra("note_id", note.id)
                        })
                    },
                    onNewNoteKeyboard = {
                        startActivity(Intent(this, NewNoteActivity::class.java).apply {
                            putExtra("mode", "keyboard")
                        })
                    },
                    onNewNoteVoice = {
                        startActivity(Intent(this, NewNoteActivity::class.java).apply {
                            putExtra("mode", "voice")
                        })
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(
    viewModel: NotesViewModel,
    onNoteClick: (Note) -> Unit,
    onNewNoteKeyboard: () -> Unit,
    onNewNoteVoice: () -> Unit
) {
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val transparency by viewModel.widgetTransparency.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var showDeleteDialog by remember { mutableStateOf<Note?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        TextField(
                            value = searchQuery,
                            onValueChange = {
                                searchQuery = it
                                viewModel.setSearchQuery(it)
                            },
                            placeholder = { Text("Notlarda ara...", color = Color.Gray) },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                cursorColor = Color(0xFFBB86FC),
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text("Notlarım", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    if (isSearchActive) {
                        IconButton(onClick = {
                            isSearchActive = false
                            searchQuery = ""
                            viewModel.setSearchQuery("")
                        }) {
                            Icon(Icons.Default.Close, contentDescription = "Kapat", tint = Color.White)
                        }
                    } else {
                        IconButton(onClick = { isSearchActive = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Ara", tint = Color.White)
                        }
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Ayarlar", tint = Color.White)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FloatingActionButton(
                    onClick = onNewNoteVoice,
                    containerColor = Color(0xFFBB86FC),
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Mic, contentDescription = "Sesle Not")
                }
                FloatingActionButton(
                    onClick = onNewNoteKeyboard,
                    containerColor = Color(0xFF03DAC6),
                    contentColor = Color.Black
                ) {
                    Icon(Icons.Default.Keyboard, contentDescription = "Klavye ile Not")
                }
            }
        },
        containerColor = Color(0xFF0A0A0A)
    ) { padding ->
        if (notes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Note,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        if (searchQuery.isNotBlank()) "Sonuç bulunamadı" else "Henüz not yok",
                        color = Color.Gray,
                        fontSize = 18.sp
                    )
                    if (searchQuery.isBlank()) {
                        Text(
                            "Mikrofon veya klavye ile ekle",
                            color = Color.DarkGray,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(notes, key = { it.id }) { note ->
                    NoteCard(
                        note = note,
                        onClick = { onNoteClick(note) },
                        onDelete = { showDeleteDialog = note },
                        onToggleTodo = {
                            scope.launch {
                                viewModel.updateNote(
                                    note.copy(
                                        isCompleted = !note.isCompleted,
                                        updatedAt = System.currentTimeMillis()
                                    )
                                )
                            }
                        },
                        onTogglePin = {
                            viewModel.togglePin(note)
                        }
                    )
                }
            }
        }
    }

    // Delete dialog
    showDeleteDialog?.let { note ->
        AlertDialog(
            onDismissRequest = { showDeleteDialog = null },
            title = { Text("Notu sil") },
            text = { Text("Bu notu silmek istediğine emin misin?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        viewModel.deleteNote(note)
                        showDeleteDialog = null
                    }
                }) {
                    Text("Sil", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = null }) {
                    Text("İptal")
                }
            }
        )
    }

    // Settings dialog
    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Widget Ayarları") },
            text = {
                Column {
                    Text("Şeffaflık: ${(transparency * 100).toInt()}%", color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Slider(
                        value = transparency,
                        onValueChange = { viewModel.setWidgetTransparency(it) },
                        valueRange = 0.3f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFBB86FC),
                            activeTrackColor = Color(0xFFBB86FC)
                        )
                    )
                    Text(
                        "0.3 = daha şeffaf  •  1.0 = tamamen opak",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "Not: Widget'ı yeniden eklemen gerekebilir.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    // Force widget update
                    showSettings = false
                }) {
                    Text("Tamam")
                }
            },
            containerColor = Color(0xFF1E1E1E),
            titleContentColor = Color.White,
            textContentColor = Color.White
        )
    }
}

@Composable
fun NoteCard(
    note: Note,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onToggleTodo: () -> Unit,
    onTogglePin: () -> Unit
) {
    val bgColor = Color(note.color)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 130.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (note.isTodo) {
                        Icon(
                            imageVector = if (note.isCompleted) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = "Todo",
                            tint = if (note.isCompleted) Color(0xFF03DAC6) else Color.Gray,
                            modifier = Modifier
                                .size(20.dp)
                                .clickable { onToggleTodo() }
                        )
                    } else {
                        Icon(
                            Icons.Default.Note,
                            contentDescription = null,
                            tint = Color(0xFFBB86FC),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    if (note.isPinned) {
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Default.PushPin,
                            contentDescription = "Sabitlenmiş",
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Row {
                    Icon(
                        if (note.isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                        contentDescription = "Sabitle",
                        tint = if (note.isPinned) Color(0xFFFFD700) else Color.Gray,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { onTogglePin() }
                    )
                    Spacer(Modifier.width(8.dp))
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Sil",
                        tint = Color.Gray,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { onDelete() }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            if (note.title.isNotBlank()) {
                Text(
                    text = note.title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
            }
            Text(
                text = note.content.ifBlank { "(boş not)" },
                color = Color(0xFFCCCCCC),
                fontSize = 13.sp,
                maxLines = 4,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )
        }
    }
}
