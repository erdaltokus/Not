package com.notewidget.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    private val TRANSPARENCY_KEY = floatPreferencesKey("widget_transparency")

    val widgetTransparency: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[TRANSPARENCY_KEY] ?: 0.90f // 0.0 = fully transparent, 1.0 = opaque
    }

    suspend fun setWidgetTransparency(value: Float) {
        context.dataStore.edit { prefs ->
            prefs[TRANSPARENCY_KEY] = value.coerceIn(0.3f, 1.0f)
        }
    }
}
