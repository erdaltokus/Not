package com.notewidget.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val isTodo: Boolean = false,
    val isCompleted: Boolean = false,
    val isPinned: Boolean = false,
    val color: Int = 0xFF1E1E1E.toInt(), // note card color
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
