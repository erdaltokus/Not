package com.notewidget.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.notewidget.app.NoteApp
import com.notewidget.app.data.Note
import com.notewidget.app.ui.theme.NoteWidgetAppTheme
import com.notewidget.app.widget.NotesWidget
import kotlinx.coroutines.launch

private val NOTE_COLORS = listOf(
    0xFF1E1E1E.toInt(),
    0xFF2D2B55.toInt(),
    0xFF1A3A2A.toInt(),
    0xFF3A2A1A.toInt(),
    0xFF2A1A3A.toInt(),
    0xFF1A2A3A.toInt(),
    0xFF3A1A1A.toInt(),
    0xFF1A3A3A.toInt()
)

class NoteDetailActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val noteId = intent.getLongExtra("note_id", -1L)
        if (noteId == -1L) {
            finish()
            return
        }

        setContent {
            NoteWidgetAppTheme {
                val app = application as NoteApp
                val viewModel: NotesViewModel = viewModel(
                    factory = NotesViewModelFactory(app.repository, app.settingsRepository)
                )
                NoteDetailScreen(
                    noteId = noteId,
                    viewModel = viewModel,
                    onBack = { finish() },
                    onDeleted = {
                        NotesWidget().updateAll(this)
                        finish()
                    },
                    onSaved = {
                        NotesWidget().updateAll(this)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteDetailScreen(
    noteId: Long,
    viewModel: NotesViewModel,
    onBack: () -> Unit,
    onDeleted: () -> Unit,
    onSaved: () -> Unit
) {
    var note by remember { mutableStateOf<Note?>(null) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var isTodo by remember { mutableStateOf(false) }
    var isCompleted by remember { mutableStateOf(false) }
    var isPinned by remember { mutableStateOf(false) }
    var selectedColor by remember { mutableStateOf(NOTE_COLORS[0]) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(noteId) {
        val loaded = (context.applicationContext as NoteApp).repository.getNoteById(noteId)
        note = loaded
        if (loaded != null) {
            title = loaded.title
            content = loaded.content
            isTodo = loaded.isTodo
            isCompleted = loaded.isCompleted
            isPinned = loaded.isPinned
            selectedColor = loaded.color
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notu Düzenle") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    IconButton(onClick = { isPinned = !isPinned }) {
                        Icon(
                            if (isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Sabitle",
                            tint = if (isPinned) Color(0xFFFFD700) else Color.White
                        )
                    }
                    IconButton(onClick = { showDeleteDialog = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Sil", tint = Color(0xFFCF6679))
                    }
                    IconButton(onClick = {
                        scope.launch {
                            note?.let {
                                val updated = it.copy(
                                    title = title,
                                    content = content,
                                    isTodo = isTodo,
                                    isCompleted = isCompleted,
                                    isPinned = isPinned,
                                    color = selectedColor,
                                    updatedAt = System.currentTimeMillis()
                                )
                                viewModel.updateNote(updated)
                                onSaved()
                                Toast.makeText(context, "Kaydedildi", Toast.LENGTH_SHORT).show()
                                onBack()
                            }
                        }
                    }) {
                        Icon(Icons.Default.Check, contentDescription = "Kaydet", tint = Color(0xFF03DAC6))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF0A0A0A)
    ) { padding ->
        if (note == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFFBB86FC))
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Başlık") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color(0xFFBB86FC)
                    ),
                    singleLine = true
                )

                Spacer(Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isTodo,
                        onCheckedChange = { isTodo = it },
                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF03DAC6))
                    )
                    Text("Yapılacaklar", color = Color.White)
                }

                if (isTodo) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = isCompleted,
                            onCheckedChange = { isCompleted = it },
                            colors = CheckboxDefaults.colors(checkedColor = Color(0xFF03DAC6))
                        )
                        Text("Tamamlandı", color = Color.White)
                    }
                }

                Spacer(Modifier.height(12.dp))

                Text("Not rengi", color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(NOTE_COLORS) { color ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(color))
                                .border(
                                    width = if (selectedColor == color) 3.dp else 1.dp,
                                    color = if (selectedColor == color) Color(0xFF03DAC6) else Color.Gray,
                                    shape = CircleShape
                                )
                                .clickable { selectedColor = color }
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("İçerik") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 250.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = Color(0xFFBB86FC)
                    ),
                    minLines = 10
                )
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Notu sil") },
            text = { Text("Bu not kalıcı olarak silinecek.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        note?.let {
                            viewModel.deleteNote(it)
                            onDeleted()
                        }
                    }
                }) {
                    Text("Sil", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("İptal")
                }
            }
        )
    }
}
