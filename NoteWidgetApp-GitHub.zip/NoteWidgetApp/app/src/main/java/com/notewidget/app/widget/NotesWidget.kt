package com.notewidget.app.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.LocalContext
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetManager
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.notewidget.app.NoteApp
import com.notewidget.app.data.Note
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class NotesWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val (notes, transparency) = withContext(Dispatchers.IO) {
            val app = context.applicationContext as NoteApp
            val notesList = app.repository.getAllNotesOnce().take(6)
            val alpha = app.settingsRepository.widgetTransparency.first()
            notesList to alpha
        }

        provideContent {
            GlanceTheme {
                WidgetContent(notes = notes, transparency = transparency)
            }
        }
    }

    suspend fun updateAll(context: Context) {
        val manager = GlanceAppWidgetManager(context)
        val ids = manager.getGlanceIds(NotesWidget::class.java)
        ids.forEach { update(context, it) }
    }
}

@Composable
private fun WidgetContent(notes: List<Note>, transparency: Float) {
    val alpha = (transparency * 255).toInt().coerceIn(80, 255)
    val bgColor = Color(0x12, 0x12, 0x12, alpha)

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor))
            .padding(12.dp)
    ) {
        Text(
            text = "Notlarım",
            style = TextStyle(
                color = ColorProvider(Color.White),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        )

        Spacer(GlanceModifier.height(8.dp))

        if (notes.isEmpty()) {
            Text(
                text = "Henüz not yok\nMikrofon veya klavye ile ekle",
                style = TextStyle(
                    color = ColorProvider(Color.Gray),
                    fontSize = 13.sp
                )
            )
        } else {
            notes.forEach { note ->
                NoteItem(note = note)
                Spacer(GlanceModifier.height(6.dp))
            }
        }

        Spacer(GlanceModifier.defaultWeight())

        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⌨️",
                style = TextStyle(fontSize = 22.sp),
                modifier = GlanceModifier
                    .clickable(actionRunCallback<NewNoteKeyboardAction>())
                    .padding(8.dp)
            )

            Spacer(GlanceModifier.defaultWeight())

            Text(
                text = "🎤",
                style = TextStyle(fontSize = 22.sp),
                modifier = GlanceModifier
                    .clickable(actionRunCallback<NewNoteVoiceAction>())
                    .padding(8.dp)
            )
        }
    }
}

@Composable
private fun NoteItem(note: Note) {
    val preview = buildString {
        if (note.isPinned) append("📌 ")
        if (note.title.isNotBlank()) append(note.title).append("\n")
        append(note.content.take(80))
        if (note.content.length > 80) append("…")
    }

    val itemBg = Color(note.color).copy(alpha = 0.95f)

    Column(
        modifier = GlanceModifier
            .fillMaxWidth()
            .background(ColorProvider(itemBg))
            .padding(8.dp)
            .clickable(actionRunCallback<OpenNoteAction>(
                actionParametersOf(ActionParameters.Key<Long>("noteId") to note.id)
            ))
    ) {
        Text(
            text = if (note.isTodo) {
                if (note.isCompleted) "☑ $preview" else "☐ $preview"
            } else {
                preview
            },
            style = TextStyle(
                color = ColorProvider(Color(0xFFEEEEEE)),
                fontSize = 12.sp
            ),
            maxLines = 3
        )
    }
}

class NewNoteKeyboardAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val intent = android.content.Intent(context, com.notewidget.app.ui.NewNoteActivity::class.java).apply {
            putExtra("mode", "keyboard")
            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}

class NewNoteVoiceAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val intent = android.content.Intent(context, com.notewidget.app.ui.NewNoteActivity::class.java).apply {
            putExtra("mode", "voice")
            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}

class OpenNoteAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val noteId = parameters[ActionParameters.Key<Long>("noteId")] ?: return
        val intent = android.content.Intent(context, com.notewidget.app.ui.NoteDetailActivity::class.java).apply {
            putExtra("note_id", noteId)
            flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}

class NotesWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = NotesWidget()
}
