package com.notewidget.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.notewidget.app.NoteApp
import com.notewidget.app.data.Note
import com.notewidget.app.ui.theme.NoteWidgetAppTheme
import com.notewidget.app.widget.NotesWidget

class NewNoteActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(this, "Mikrofon izni gerekli", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val mode = intent.getStringExtra("mode") ?: "keyboard"
        val startVoice = mode == "voice"

        if (startVoice) {
            checkAudioPermission()
        }

        setContent {
            NoteWidgetAppTheme {
                val app = application as NoteApp
                val viewModel: NotesViewModel = viewModel(
                    factory = NotesViewModelFactory(app.repository, app.settingsRepository)
                )
                NewNoteScreen(
                    startWithVoice = startVoice,
                    onSave = { title, content, isTodo, color ->
                        viewModel.insertNote(
                            Note(
                                title = title,
                                content = content,
                                isTodo = isTodo,
                                color = color,
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                        NotesWidget().updateAll(this)
                        finish()
                    },
                    onBack = { finish() },
                    onRequestPermission = { checkAudioPermission() }
                )
            }
        }
    }

    private fun checkAudioPermission() {
        when {
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED -> { }
            else -> requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}

private val NOTE_COLORS = listOf(
    0xFF1E1E1E.toInt(), // dark
    0xFF2D2B55.toInt(), // purple dark
    0xFF1A3A2A.toInt(), // green dark
    0xFF3A2A1A.toInt(), // brown
    0xFF2A1A3A.toInt(), // deep purple
    0xFF1A2A3A.toInt(), // blue dark
    0xFF3A1A1A.toInt(), // red dark
    0xFF1A3A3A.toInt()  // teal dark
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewNoteScreen(
    startWithVoice: Boolean,
    onSave: (String, String, Boolean, Int) -> Unit,
    onBack: () -> Unit,
    onRequestPermission: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var isTodo by remember { mutableStateOf(false) }
    var selectedColor by remember { mutableStateOf(NOTE_COLORS[0]) }
    var isListening by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    fun startListening() {
        if (speechRecognizer == null) {
            Toast.makeText(context, "Ses tanıma desteklenmiyor", Toast.LENGTH_SHORT).show()
            return
        }
        onRequestPermission()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(error: Int) {
                isListening = false
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "Ses anlaşılamadı"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Zaman aşımı"
                    SpeechRecognizer.ERROR_NETWORK -> "Ağ hatası (offline paket yükle)"
                    else -> "Hata: $error"
                }
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spoken = matches[0]
                    content = if (content.isBlank()) spoken else "$content $spoken"
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        isListening = false
    }

    LaunchedEffect(startWithVoice) {
        if (startWithVoice) startListening()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (startWithVoice) "Sesli Not" else "Yeni Not") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        if (content.isNotBlank() || title.isNotBlank()) {
                            onSave(title, content, isTodo, selectedColor)
                        } else {
                            Toast.makeText(context, "Boş not kaydedilemez", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Default.Check, contentDescription = "Kaydet", tint = Color(0xFF03DAC6))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF0A0A0A)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Başlık (opsiyonel)") },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFBB86FC),
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = Color(0xFFBB86FC),
                    cursorColor = Color(0xFFBB86FC),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true
            )

            Spacer(Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = isTodo,
                    onCheckedChange = { isTodo = it },
                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF03DAC6), uncheckedColor = Color.Gray)
                )
                Text("Yapılacaklar listesi olarak kaydet", color = Color.White)
            }

            Spacer(Modifier.height(12.dp))

            Text("Not rengi", color = Color.Gray, fontSize = MaterialTheme.typography.bodySmall.fontSize)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(NOTE_COLORS) { color ->
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(color))
                            .border(
                                width = if (selectedColor == color) 3.dp else 1.dp,
                                color = if (selectedColor == color) Color(0xFF03DAC6) else Color.Gray,
                                shape = CircleShape
                            )
                            .clickable { selectedColor = color }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("Not içeriği") },
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFBB86FC),
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = Color(0xFFBB86FC),
                    cursorColor = Color(0xFFBB86FC),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                minLines = 8
            )

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = { if (isListening) stopListening() else startListening() },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isListening) Color(0xFFCF6679) else Color(0xFFBB86FC)
                )
            ) {
                Icon(if (isListening) Icons.Default.MicOff else Icons.Default.Mic, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (isListening) "Dinleniyor... (durdur)" else "Sesle Yaz", fontWeight = FontWeight.Medium)
            }

            if (isListening) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Konuşmaya başla (Türkçe offline tercih edilir)",
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}
