# Not Widget App (v1.1)

Sadece senin telefonunda çalışacak kişisel not + widget uygulaması.

## Yeni Eklenen Özellikler

- **Widget şeffaflık ayarı** (Ayarlar ikonundan)
- **Not renk seçimi** (8 koyu renk)
- **Arama** (üst bardaki büyüteç)
- **Pinleme / Sabitleme** (önemli notlar en üstte)

## Tüm Özellikler

- Ana ekran widget'ı (boyutlandırılabilir, koyu + ayarlanabilir şeffaflık)
- Notlar grid şeklinde listelenir
- Her notta en az 3-4 satır görünür
- Widget'ta ⌨️ Klavye ve 🎤 Mikrofon butonları
- Offline ses tanıma (Türkçe tercih edilir)
- Normal not + Yapılacaklar listesi
- Not silme / düzenleme / tamamlandı işareti
- Pinleme (sabitlenen notlar üstte)
- Arama
- Not rengi seçimi

## Nasıl Kurulur?

### 1. Android Studio Kur
https://developer.android.com/studio

### 2. Projeyi Aç
Android Studio → Open → `NoteWidgetApp` klasörünü seç  
Gradle sync bitmesini bekle.

### 3. Telefona Yükle
1. Geliştirici seçenekleri + USB hata ayıklama aç
2. Telefonu USB ile bağla
3. Android Studio'da yeşil **Run** (▶) bas

### Alternatif APK
Build → Build Bundle(s) / APK(s) → Build APK(s)

## Offline Ses
Samsung S25 Ultra:
Ayarlar → Genel yönetim → Dil ve giriş  
veya Google → Ses → Offline konuşma tanıma → **Türkçe** indir

## Widget
Ana ekranda uzun bas → Widget'lar → **Not Widget**

## Not
Uygulama sadece sideload. Veriler sadece telefonunda.
